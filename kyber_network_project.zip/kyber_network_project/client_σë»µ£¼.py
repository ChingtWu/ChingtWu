import hashlib
import socket
import os
import time
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QFileDialog, QLabel, QPushButton, QLineEdit, QVBoxLayout, QWidget
from pqcrypto.kem.kyber512 import generate_keypair, encrypt, decrypt
from Crypto.Cipher import AES

# 客户端生成临时公私钥对
client_epk, client_esk = generate_keypair()

def derive_session_key(pk, epk, C1, C2, k1, k2):
    hash_input = pk + epk + C1 + C2 + k1 + k2
    return hashlib.sha256(hash_input).digest()

def get_server_public_key(sock):
    server_pk = sock.recv(800)  # 接收服务器的公钥
    print(f"Received server public key: {len(server_pk)} bytes")
    return server_pk

def encapsulate_server_key(server_pk):
    C1, k1 = encrypt(server_pk)
    print(f"Generated C1: {len(C1)} bytes")
    return C1, k1

def send_and_receive_data(sock, C1, client_epk):
    sock.sendall(C1)
    sock.sendall(client_epk)
    print(f"Sent C1: {len(C1)} bytes, client_epk: {len(client_epk)} bytes")
    C2 = sock.recv(736)  # 接收C2
    nonce = sock.recv(16)
    tag = sock.recv(16)
    encrypted_message = sock.recv(1024)
    print(f"Received C2: {len(C2)} bytes, nonce: {len(nonce)} bytes, tag: {len(tag)} bytes, encrypted_message: {len(encrypted_message)} bytes")
    return C2, nonce, tag, encrypted_message

def process_received_data(C2, nonce, tag, encrypted_message, client_esk):
    k2 = decrypt(client_esk, C2)
    session_key = derive_session_key(server_pk, client_epk, C1, C2, k1, k2)
    cipher = AES.new(session_key, AES.MODE_EAX, nonce=nonce)
    verification_message = cipher.decrypt_and_verify(encrypted_message, tag)
    print("Verification Message:", verification_message.decode())
    return session_key

def log_client_data(client_dir, data, filename):
    os.makedirs(client_dir, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    with open(os.path.join(client_dir, f"{filename}_{timestamp}.bin"), "wb") as f:
        f.write(data)

# 接收并解密服务器的消息
def receive_and_decrypt_message(sock, session_key, client_dir):
    while True:
        # 接收加密数据
        encrypted_data = sock.recv(4096)
        if not encrypted_data:
            break
        
        nonce = encrypted_data[:16]
        tag = encrypted_data[16:32]
        ciphertext = encrypted_data[32:]
        
        cipher = AES.new(session_key, AES.MODE_EAX, nonce=nonce)
        try:
            message = cipher.decrypt_and_verify(ciphertext, tag)
            print(f"Received and decrypted message: {message.decode()}")

            # 将解密后的消息保存到客户端日志中
            log_client_data(client_dir, message, "received_message")

        except ValueError:
            print("Decryption failed: MAC check failed.")

# 使用 PyQt5 实现界面
# 使用 PyQt5 实现界面
class SimpleUI(QWidget):
    def __init__(self, session_key, sock, client_dir):
        super().__init__()
        self.session_key = session_key
        self.sock = sock
        self.client_dir = client_dir
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Secure File and Message Transfer")

        # 创建界面控件
        self.file_label = QLabel("File:")
        self.file_path_edit = QLineEdit(self)
        self.browse_button = QPushButton("Browse", self)
        self.send_file_button = QPushButton("Send File", self)

        # 文本消息发送相关控件
        self.message_label = QLabel("Message:")
        self.message_edit = QLineEdit(self)
        self.send_message_button = QPushButton("Send Message", self)

        # 设置布局
        layout = QVBoxLayout()
        
        # 文件传输部分
        layout.addWidget(self.file_label)
        layout.addWidget(self.file_path_edit)
        layout.addWidget(self.browse_button)
        layout.addWidget(self.send_file_button)
        
        # 消息传输部分
        layout.addWidget(self.message_label)
        layout.addWidget(self.message_edit)
        layout.addWidget(self.send_message_button)

        self.setLayout(layout)

        # 绑定事件
        self.browse_button.clicked.connect(self.browse_file)
        self.send_file_button.clicked.connect(self.send_file)
        self.send_message_button.clicked.connect(self.send_message)

    def browse_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select File")
        self.file_path_edit.setText(file_path)

    def send_file(self):
        file_path = self.file_path_edit.text()
        if file_path:
            with open(file_path, 'rb') as f:
                data = f.read()
            encrypted_data = self.encrypt_data(data, self.session_key)

            # Log the file before sending
            log_client_data(self.client_dir, encrypted_data, os.path.basename(file_path) + "_sent")

            self.sock.sendall(encrypted_data)
            print("File sent successfully")

    def send_message(self):
        message = self.message_edit.text().encode('utf-8')  # 将消息转换为字节
        if message:
            encrypted_data = self.encrypt_data(message, self.session_key)

            # Log the message before sending
            log_client_data(self.client_dir, encrypted_data, "sent_message")

            self.sock.sendall(encrypted_data)
            print("Message sent successfully")

    def encrypt_data(self, data, session_key):
        cipher = AES.new(session_key, AES.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(data)
        print(f"Nonce: {len(cipher.nonce)}, Tag: {len(tag)}, Ciphertext: {len(ciphertext)}")
        return cipher.nonce + tag + ciphertext


if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    client_dir = "client_logs"

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect(('127.0.0.1', 6666))  # 使用本地地址
        server_pk = get_server_public_key(sock)
        C1, k1 = encapsulate_server_key(server_pk)
        
        # Log C1 and client_epk
        log_client_data(client_dir, C1, "C1.bin")
        log_client_data(client_dir, client_epk, "client_epk.bin")

        C2, nonce, tag, encrypted_message = send_and_receive_data(sock, C1, client_epk)
        session_key = process_received_data(C2, nonce, tag, encrypted_message, client_esk)

        app = QApplication(sys.argv)
        ui = SimpleUI(session_key, sock, client_dir)
        ui.show()

        # 在另一个线程中启动接收服务器消息的功能
        import threading
        receive_thread = threading.Thread(target=receive_and_decrypt_message, args=(sock, session_key, client_dir))
        receive_thread.start()
        
        sys.exit(app.exec_())

        # 等待接收线程结束
        receive_thread.join()