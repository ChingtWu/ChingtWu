import hashlib
import socket
import threading
import os
import time
from pqcrypto.kem.kyber512 import generate_keypair, encrypt, decrypt
from Crypto.Cipher import AES
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QListWidget, QTextEdit, QLineEdit, QPushButton, QFileDialog
import sys

# 生成服务器的长期公私钥对
server_pk, server_sk = generate_keypair()
clients = {}

# 发送公钥给客户端
def send_public_key(client_socket):
    client_socket.sendall(server_pk)
    print(f"Sent server public key: {len(server_pk)} bytes")

# 接收客户端数据
def receive_client_data(client_socket):
    C1 = client_socket.recv(736)
    client_epk = client_socket.recv(800)
    print(f"Received C1: {len(C1)} bytes, client_epk: {len(client_epk)} bytes")
    return C1, client_epk

# 处理密钥
def process_keys(C1, client_epk, server_sk):
    k1 = decrypt(server_sk, C1)
    C2, k2 = encrypt(client_epk)
    return k1, k2, C2

# 派生会话密钥
def derive_session_key(pk, epk, C1, C2, k1, k2):
    hash_input = pk + epk + C1 + C2 + k1 + k2
    return hashlib.sha256(hash_input).digest()

# 发送验证消息
def send_verification_message(client_socket, session_key, C2):
    cipher = AES.new(session_key, AES.MODE_EAX)
    nonce = cipher.nonce
    encrypted_message, tag = cipher.encrypt_and_digest(b"Verification Message")
    client_socket.sendall(C2 + nonce + tag + encrypted_message)
    print(f"Sent C2: {len(C2)} bytes, nonce: {len(nonce)} bytes, tag: {len(tag)} bytes,session key: {len(session_key)}bytes, encrypted_message: {len(encrypted_message)} bytes")

# 接收并解密文件
def receive_and_decrypt_file(client_socket, session_key, client_dir):
    file_counter = 1
    while True:
        encrypted_file_data = client_socket.recv(4096)
        if not encrypted_file_data:
            break
        nonce = encrypted_file_data[:16]
        tag = encrypted_file_data[16:32]
        ciphertext = encrypted_file_data[32:]

        cipher = AES.new(session_key, AES.MODE_EAX, nonce=nonce)
        try:
            file_data = cipher.decrypt_and_verify(ciphertext, tag)
            
            # 使用计数器生成唯一的文件名
            file_name = f"received_file_{file_counter}.bin"
            with open(os.path.join(client_dir, file_name), "wb") as f:
                f.write(file_data)
            
            print(f"File {file_name} received and decrypted successfully.")
            file_counter += 1
        except ValueError:
            print("Decryption failed: MAC check failed.")

# 处理客户端连接
def handle_client_connection(client_socket, client_addr, gui_update_signal, message_received_signal):
    try:
        client_dir = f"logs/{client_addr[0]}_{client_addr[1]}"
        os.makedirs(client_dir, exist_ok=True)

        send_public_key(client_socket)
        C1, client_epk = receive_client_data(client_socket)

        # 记录收到的C1和client_epk
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        with open(os.path.join(client_dir, f"C1_{timestamp}.bin"), "wb") as f:
            f.write(C1)
        with open(os.path.join(client_dir, f"client_epk_{timestamp}.bin"), "wb") as f:
            f.write(client_epk)

        k1, k2, C2 = process_keys(C1, client_epk, server_sk)
        session_key = derive_session_key(server_pk, client_epk, C1, C2, k1, k2)
        send_verification_message(client_socket, session_key, C2)

        # 将客户端添加到全局客户端列表中
        clients[client_addr] = {
            "socket": client_socket,
            "session_key": session_key,
            "dir": client_dir
        }
        print(f"Client {client_addr} added to list.")

        # 发送信号更新客户端列表
        gui_update_signal.emit()

        # 接收并显示来自客户端的消息
        while True:
            encrypted_message = client_socket.recv(1024)
            if not encrypted_message:
                break
            nonce = encrypted_message[:16]
            tag = encrypted_message[16:32]
            ciphertext = encrypted_message[32:]
            cipher = AES.new(session_key, AES.MODE_EAX, nonce=nonce)
            try:
                message = cipher.decrypt_and_verify(ciphertext, tag).decode()
                print(f"Received from {client_addr}: {message}")
                # 发送信号更新消息显示
                message_received_signal.emit(f"Received from {client_addr}: {message}")
            except ValueError:
                print("Decryption failed: MAC check failed.")
                break

        receive_and_decrypt_file(client_socket, session_key, client_dir)
    except Exception as e:
        print(f"Error handling client {client_addr}: {e}")
    finally:
        client_socket.close()
        del clients[client_addr]
        print(f"Connection closed: {client_addr}")
        gui_update_signal.emit()

# 启动服务器
def start_server(gui_update_signal, message_received_signal):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('127.0.0.1', 6666))
    server.listen(5)
    print("Server listening on port 6666")
    
    while True:
        client_socket, addr = server.accept()
        print(f"Accepted connection from {addr}")
        threading.Thread(target=handle_client_connection, args=(client_socket, addr, gui_update_signal, message_received_signal)).start()

# 服务器GUI类使用PyQt5实现
class ServerGUI(QMainWindow):
    update_signal = QtCore.pyqtSignal()  # 用于更新客户端列表的信号
    message_received_signal = QtCore.pyqtSignal(str)  # 用于显示接收的消息

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Server GUI")
        self.setGeometry(100, 100, 600, 400)

        # 客户端列表
        self.client_listbox = QListWidget(self)
        self.client_listbox.setGeometry(10, 10, 200, 300)

        # 消息显示
        self.chat_display = QTextEdit(self)
        self.chat_display.setGeometry(220, 10, 360, 150)
        self.chat_display.setReadOnly(True)

        # 消息输入
        self.message_entry = QLineEdit(self)
        self.message_entry.setGeometry(10, 320, 400, 30)

        # 发送消息按钮
        self.send_button = QPushButton("Send Message", self)
        self.send_button.setGeometry(420, 320, 160, 30)
        self.send_button.clicked.connect(self.send_message)

        # 选择文件并发送按钮
        self.file_button = QPushButton("Select and Send File", self)
        self.file_button.setGeometry(10, 360, 570, 30)
        self.file_button.clicked.connect(self.send_file)

        # 连接更新客户端列表的信号
        self.update_signal.connect(self.update_client_list)
        self.message_received_signal.connect(self.update_chat_display)
        self.update_client_list()

    def update_client_list(self):
        self.client_listbox.clear()
        for idx, addr in enumerate(clients.keys()):
            self.client_listbox.addItem(f"Client_{idx + 1}: {addr}")

    def send_message(self):
        selected_client = self.client_listbox.currentRow()
        if selected_client != -1:
            client_addr = list(clients.keys())[selected_client]
            message = self.message_entry.text().encode()
            encrypted_message = self.encrypt_message(clients[client_addr]['session_key'], message)
            clients[client_addr]['socket'].sendall(encrypted_message)
            self.chat_display.append(f"Sent to {client_addr}: {message.decode()}")
            self.message_entry.clear()

    def encrypt_message(self, session_key, message):
        cipher = AES.new(session_key, AES.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(message)
        return cipher.nonce + tag + ciphertext

    def send_file(self):
        selected_client = self.client_listbox.currentRow()
        if selected_client != -1:
            client_addr = list(clients.keys())[selected_client]
            file_path, _ = QFileDialog.getOpenFileName(self, "Select File")
            if file_path:
                with open(file_path, 'rb') as f:
                    file_data = f.read()
                encrypted_file = self.encrypt_message(clients[client_addr]['session_key'], file_data)
                clients[client_addr]['socket'].sendall(encrypted_file)
                self.chat_display.append(f"File sent to {client_addr}: {file_path}")

    def update_chat_display(self, message):
        self.chat_display.append(message)

# 运行服务器GUI
def main():
    app = QApplication(sys.argv)
    gui = ServerGUI()
    gui.show()

    # 启动服务器线程，传递更新信号
    threading.Thread(target=start_server, args=(gui.update_signal, gui.message_received_signal), daemon=True).start()

    sys.exit(app.exec_())

if __name__ == "__main__":
    main()